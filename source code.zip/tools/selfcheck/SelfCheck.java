import com.xdk.xdkspin.PitchMode;
import com.xdk.xdkspin.SpinMath;
import com.xdk.xdkspin.SpinMode;
import com.xdk.xdkspin.gui.PanelLayout;

/**
 * 纯数学自检，不依赖 Minecraft。用 tools 目录单独 javac 编译运行：
 *   javac -encoding UTF-8 -d build/selfcheck tools/selfcheck/SelfCheck.java \
 *         src/main/java/com/xdk/xdkspin/SpinMath.java src/main/java/com/xdk/xdkspin/SpinMode.java \
 *         src/main/java/com/xdk/xdkspin/PitchMode.java
 *   java -cp build/selfcheck SelfCheck
 */
public class SelfCheck {
	private static int failures = 0;

	public static void main(String[] args) {
		// ---- 每秒圈数模式 ----
		check("1 圈/秒 = 18°/tick", SpinMath.degreesPerTick(SpinMode.RPS, 1.0, 18.0, 5.0, 15.0), 18.0, 1e-9);
		check("0.5 圈/秒 = 9°/tick", SpinMath.degreesPerTick(SpinMode.RPS, 0.5, 99.0, 5.0, 15.0), 9.0, 1e-9);
		check("10 圈/秒 = 180°/tick", SpinMath.degreesPerTick(SpinMode.RPS, 10.0, 1.0, 5.0, 15.0), 180.0, 1e-9);

		// ---- 单步角度模式 ----
		check("单步模式直接取角度", SpinMath.degreesPerTick(SpinMode.STEP, 5.0, 7.5, 5.0, 15.0), 7.5, 1e-9);
		check("单步模式下限 0.1 度", SpinMath.degreesPerTick(SpinMode.STEP, 5.0, 0.1, 5.0, 15.0), 0.1, 1e-9);

		// ---- 自定义模式：每次角度 × 每秒尝试次数 ----
		check("5 次/秒 × 15° = 3.75°/tick", SpinMath.degreesPerTick(SpinMode.CUSTOM, 1.0, 18.0, 5.0, 15.0), 3.75, 1e-9);
		check("20 次/秒 × 18° = 18°/tick", SpinMath.degreesPerTick(SpinMode.CUSTOM, 1.0, 1.0, 20.0, 18.0), 18.0, 1e-9);
		check("4 次/秒 × 45° = 9°/tick", SpinMath.degreesPerTick(SpinMode.CUSTOM, 1.0, 1.0, 4.0, 45.0), 9.0, 1e-9);
		check("0.05 次/秒 × 0.1° 极小值", SpinMath.degreesPerTick(SpinMode.CUSTOM, 1.0, 1.0, 0.05, 0.1), 0.00025, 1e-12);

		// ---- 角度折算 ----
		check("18°/tick 反推 1 圈/秒", SpinMath.rotationsPerSecond(18.0), 1.0, 1e-9);
		check("9°/tick 反推 0.5 圈/秒", SpinMath.rotationsPerSecond(9.0), 0.5, 1e-9);
		check("wrap 190 -> -170", SpinMath.wrapDegrees(190.0), -170.0, 1e-6);
		check("wrap -190 -> 170", SpinMath.wrapDegrees(-190.0), 170.0, 1e-6);
		check("wrap 360 -> 0", SpinMath.wrapDegrees(360.0), 0.0, 1e-6);
		check("wrap 180 -> -180", SpinMath.wrapDegrees(180.0), -180.0, 1e-6);
		check("wrap 719 -> -1", SpinMath.wrapDegrees(719.0), -1.0, 1e-6);

		// ---- 连续模式：20 tick 转满 1 圈回到起点 ----
		float offset = 0.0F;
		double perTick = SpinMath.degreesPerTick(SpinMode.RPS, 1.0, 18.0, 5.0, 15.0);
		for (int i = 0; i < 20; i++) {
			offset = SpinMath.advance(offset, perTick, true);
		}
		check("顺时针转满 1 圈回到起点", offset, 0.0, 1e-3);

		offset = 0.0F;
		for (int i = 0; i < 20; i++) {
			offset = SpinMath.advance(offset, perTick, false);
		}
		check("逆时针转满 1 圈回到起点", offset, 0.0, 1e-3);

		// ---- 每一步都落在 [-180,180) ----
		offset = 0.0F;
		boolean inRange = true;
		boolean sawHalf = false;
		for (int i = 0; i < 20; i++) {
			offset = SpinMath.advance(offset, perTick, true);
			if (offset < -180.0F || offset >= 180.0F) {
				inRange = false;
			}
			if (offset >= 160.0F && offset <= 179.9F) {
				sawHalf = true;
			}
		}
		check("每步都落在 [-180,180)", inRange ? 1.0 : 0.0, 1.0, 1e-9);
		check("20 步能覆盖到接近 180 度", sawHalf ? 1.0 : 0.0, 1.0, 1e-9);

		// ---- 自定义模式的累加器：复刻 SpinController 的逻辑，验证长期频率与平均值一致 ----
		check("累加器：5 次/秒 × 15°，1 秒内正好 5 步", simulateSteps(5.0, 15.0, 20), 5.0, 1e-9);
		check("累加器：3 次/秒，1 秒内 3 步（非整除频率）", simulateSteps(3.0, 15.0, 20), 3.0, 1e-9);
		check("累加器：3 次/秒，3 秒内 9 步（不漂移）", simulateSteps(3.0, 15.0, 60), 9.0, 1e-9);
		check("累加器：20 次/秒 = 每 tick 一步", simulateSteps(20.0, 18.0, 20), 20.0, 1e-9);
		check("累加器：0.5 次/秒，10 秒内 5 步", simulateSteps(0.5, 30.0, 200), 5.0, 1e-9);
		check("累加器：跳跃总角度 = 平均换算 × 秒数",
			simulateTotalDegrees(5.0, 15.0, 40),
			SpinMath.degreesPerTick(SpinMode.CUSTOM, 1.0, 1.0, 5.0, 15.0) * 40,
			1e-6);

		check("枚举项数量", PitchMode.values().length, 3.0, 0.0);
		check("旋转模式数量", SpinMode.values().length, 3.0, 0.0);

		// ---- 面板布局：常见分辨率 ÷ GUI 缩放后的 GUI 尺寸（8 行控件）----
		int[][] sizes = {{960, 540}, {854, 480}, {683, 384}, {640, 360}, {480, 270}};
		for (int[] size : sizes) {
			int w = size[0];
			int h = size[1];
			PanelLayout l = PanelLayout.compute(w, h, 8);
			String tag = "布局 " + w + "x" + h;
			check(tag + " 行距 >= 控件高度（不重叠）", l.rowStep >= PanelLayout.ROW_HEIGHT ? 1 : 0, 1.0, 0.0);
			check(tag + " 控件+提示竖向放得下", l.fitsVertically() ? 1 : 0, 1.0, 0.0);
			check(tag + " 提示不与末行控件重叠", l.noticeOverlapsContent() ? 0 : 1, 1.0, 0.0);
			check(tag + " 两列横向放得下", l.fitsHorizontally() ? 1 : 0, 1.0, 0.0);
			check(tag + " 完成按钮不压控件", l.doneClearsContent() ? 1 : 0, 1.0, 0.0);
			check(tag + " 两列不重叠", l.leftX + l.columnWidth < l.rightX ? 1 : 0, 1.0, 0.0);
			check(tag + " 提示水平居中于屏幕正中", l.noticeCenteredOnScreen() ? 1 : 0, 1.0, 0.0);
			check(tag + " 提示折行宽度在屏幕内", PanelLayout.noticeWrapWidth(w) > 0 && PanelLayout.noticeWrapWidth(w) <= w ? 1 : 0, 1.0, 0.0);
			check(tag + " 两列中点 = 屏幕中点", l.leftX + (l.columnWidth * 2 + PanelLayout.GAP) / 2 == w / 2 ? 1 : 0, 1.0, 0.0);
			check(tag + " 提示绘制中心 = 屏幕中点", PanelLayout.noticeCenterX(w) == w / 2 ? 1 : 0, 1.0, 0.0);
		}

		// 行距随屏幕变矮而收紧，但仍不小于控件高度
		check("1080p/缩放2 行距 = 23", PanelLayout.compute(960, 540, 8).rowStep, 23.0, 0.0);

		// 颜色必须带不透明 alpha，否则文字会被画成完全透明（等于消失）
		check("黄色补成不透明 ARGB", PanelLayout.opaqueColor(0xFFFF55) == 0xFFFFFF55 ? 1 : 0, 1.0, 0.0);
		check("灰色补成不透明 ARGB", PanelLayout.opaqueColor(0xAAAAAA) == 0xFFAAAAAA ? 1 : 0, 1.0, 0.0);
		check("红色补成不透明 ARGB", PanelLayout.opaqueColor(0xFF5555) == 0xFFFF5555 ? 1 : 0, 1.0, 0.0);
		check("空颜色回退为不透明白", PanelLayout.opaqueColor(null) == 0xFFFFFFFF ? 1 : 0, 1.0, 0.0);
		check("alpha 一定不为 0", (PanelLayout.opaqueColor(0x123456) >>> 24) == 0xFF ? 1 : 0, 1.0, 0.0);
		check("1080p/缩放4 行距收紧到 20", PanelLayout.compute(480, 270, 8).rowStep, 20.0, 0.0);
		check("列宽上限 200", PanelLayout.compute(1920, 1080, 8).columnWidth, 200.0, 0.0);
		check("窗口很窄时列宽不小于 110", PanelLayout.compute(240, 270, 8).columnWidth >= 110 ? 1 : 0, 1.0, 0.0);

		if (failures == 0) {
			System.out.println("全部自检通过");
		} else {
			System.out.println(failures + " 项自检失败");
			System.exit(1);
		}
	}

	/** 复刻 SpinController 的累加器，返回给定 tick 数内实际跳跃的次数。 */
	private static double simulateSteps(double attemptsPerSecond, double stepAngle, int ticks) {
		double accumulator = 0.0;
		int steps = 0;
		for (int i = 0; i < ticks; i++) {
			accumulator += attemptsPerSecond;
			while (accumulator >= SpinMath.TICKS_PER_SECOND) {
				accumulator -= SpinMath.TICKS_PER_SECOND;
				steps++;
			}
		}
		return steps;
	}

	/** 同上，但返回累计跳跃的总角度（不做角度折叠，便于和平均值比较）。 */
	private static double simulateTotalDegrees(double attemptsPerSecond, double stepAngle, int ticks) {
		double accumulator = 0.0;
		double total = 0.0;
		for (int i = 0; i < ticks; i++) {
			accumulator += attemptsPerSecond;
			while (accumulator >= SpinMath.TICKS_PER_SECOND) {
				accumulator -= SpinMath.TICKS_PER_SECOND;
				total += stepAngle;
			}
		}
		return total;
	}

	private static void check(String name, double actual, double expected, double epsilon) {
		boolean ok = Math.abs(actual - expected) <= epsilon;
		if (!ok) {
			failures++;
		}
		System.out.printf("%s %s (actual=%s expected=%s)%n", ok ? "[ok]" : "[FAIL]", name, actual, expected);
	}
}
