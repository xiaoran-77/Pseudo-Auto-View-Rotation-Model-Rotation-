package com.xdk.xdkspin;

import com.xdk.xdkspin.gui.XdkSpinScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

/**
 * 客户端入口：注册按键、tick 事件，F8 开面板，F7 快捷开关。
 */
public class XdkSpinClient implements ClientModInitializer {
	public static final String MOD_ID = "xdkspin";

	private static KeyBinding openPanelKey;
	private static KeyBinding toggleKey;
	/** 自定义按键分类（在"按键控制"里单开一页），标题由 key.category.xdkspin.rotation 决定。 */
	private static KeyBinding.Category keyCategory;

	@Override
	public void onInitializeClient() {
		XdkSpinConfig.load();

		// 1.21.11 起 KeyBinding 的第 4 个参数是 KeyBinding.Category（不再是字符串分类）。
		// 注意：同一个 id 只能注册一次，重复调用会抛 IllegalArgumentException。
		keyCategory = KeyBinding.Category.create(Identifier.of(MOD_ID, "rotation"));

		openPanelKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
			"key.xdkspin.open_panel", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_F8, keyCategory));
		toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
			"key.xdkspin.toggle", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_F7, keyCategory));

		ClientTickEvents.START_CLIENT_TICK.register(SpinController.get()::onStartTick);
		ClientTickEvents.END_CLIENT_TICK.register(this::onEndClientTick);

		XdkSpinLog.info("已加载：F8 打开设置面板，F7 开关自动旋转。");
	}

	private void onEndClientTick(MinecraftClient client) {
		while (openPanelKey.wasPressed()) {
			client.setScreen(new XdkSpinScreen(client.currentScreen));
		}
		while (toggleKey.wasPressed()) {
			toggle(client, null);
		}
		SpinController.get().onEndTick(client);
	}

	/** @param newValue null 表示切换，否则设为指定值。 */
	public static void toggle(MinecraftClient client, Boolean newValue) {
		XdkSpinConfig config = XdkSpinConfig.get();
		config.enabled = newValue != null ? newValue : !config.enabled;
		XdkSpinConfig.save();
		if (!config.enabled) {
			SpinController.get().disable(client.player);
		}
		if (config.chatFeedback && client.inGameHud != null) {
			client.inGameHud.getChatHud().addMessage(feedbackText(config.enabled));
		}
	}

	private static Text feedbackText(boolean enabled) {
		return Text.translatable("chat.xdkspin.prefix").formatted(Formatting.YELLOW)
			.append(Text.translatable(enabled ? "chat.xdkspin.on" : "chat.xdkspin.off")
				.formatted(enabled ? Formatting.GREEN : Formatting.RED));
	}
}
