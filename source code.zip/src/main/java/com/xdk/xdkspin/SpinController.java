package com.xdk.xdkspin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;

/**
 * 旋转状态机。
 *
 * <p>核心思路：客户端发往服务端的玩家朝向（PlayerMoveC2SPacket 里的 yaw/pitch）是客户端说了算的，
 * 服务端会把它转发给其他玩家。这里只替换网络出口上的数值，本地摄像机、输入、移动全都不动，
 * 所以自己的操作完全不受影响，而其他玩家看到的模型会一直旋转。
 */
public final class SpinController {
	private static final SpinController INSTANCE = new SpinController();
	/** 单 tick 内最多跳跃几次，纯粹防手改配置导致的死循环。 */
	private static final int MAX_STEPS_PER_TICK = 64;

	/** 当前累计的旋转偏移（度）。 */
	private float offsetDegrees;
	/** 自定义模式的频率累加器：每 tick 加一次“每秒次数”，满 20 就跳一步。 */
	private double stepAccumulator;
	/** 是否正在伪造朝向。 */
	private boolean spinning;
	/** 本 tick 是否已经发出过伪造朝向的包。 */
	private boolean fakeRotationSentThisTick;
	/** 防止自己补发的“真实朝向”包又被改写。 */
	private boolean bypassRewrite;
	/** 用于检测玩家实例变化（换世界/重生）。 */
	private Entity trackedPlayer;

	private SpinController() {
	}

	public static SpinController get() {
		return INSTANCE;
	}

	public boolean isSpinning() {
		return spinning;
	}

	public boolean isBypassing() {
		return bypassRewrite;
	}

	public boolean hasFakeRotationSentThisTick() {
		return fakeRotationSentThisTick;
	}

	public float getOffsetDegrees() {
		return offsetDegrees;
	}

	public void markFakeRotationSent() {
		fakeRotationSentThisTick = true;
	}

	/** 每个客户端 tick 开始时重置标记。 */
	public void onStartTick(MinecraftClient client) {
		fakeRotationSentThisTick = false;
	}

	/** 每个客户端 tick 结束时推进旋转，并在原版没有发朝向包时补一个。 */
	public void onEndTick(MinecraftClient client) {
		ClientPlayerEntity player = client.player;
		if (player == null || client.world == null || client.getNetworkHandler() == null) {
			reset();
			return;
		}
		if (trackedPlayer != player) {
			trackedPlayer = player;
			offsetDegrees = 0.0F;
			stepAccumulator = 0.0;
			spinning = false;
		}

		XdkSpinConfig config = XdkSpinConfig.get();
		if (!config.enabled || isBlocked(player, config)) {
			if (spinning) {
				disable(player);
			}
			return;
		}

		if (config.spinMode == SpinMode.CUSTOM) {
			// 按“每秒尝试次数”跳跃：不是每 tick 均匀铺开，而是攒够一次跳一次
			stepAccumulator += config.customAttemptsPerSecond;
			int steps = 0;
			while (stepAccumulator >= SpinMath.TICKS_PER_SECOND && steps < MAX_STEPS_PER_TICK) {
				stepAccumulator -= SpinMath.TICKS_PER_SECOND;
				offsetDegrees = SpinMath.advance(offsetDegrees, config.customStepAngle, config.clockwise);
				steps++;
			}
		} else {
			stepAccumulator = 0.0;
			offsetDegrees = SpinMath.advance(offsetDegrees, config.degreesPerTick(), config.clockwise);
		}

		spinning = true;
		if (!fakeRotationSentThisTick) {
			sendRotation(client, player, fakeYaw(player), fakePitch(player));
			fakeRotationSentThisTick = true;
		}
	}

	/** 自动停止条件。 */
	public static boolean isBlocked(ClientPlayerEntity player, XdkSpinConfig config) {
		if (player.isSpectator()) {
			return true;
		}
		if (config.stopWhileDead && !player.isAlive()) {
			return true;
		}
		if (config.stopWhileSwimming && player.isSwimming()) {
			return true;
		}
		if (config.stopWhileGliding && player.isGliding()) {
			return true;
		}
		if (config.stopWhileRiding && player.hasVehicle()) {
			return true;
		}
		return false;
	}

	/** 发往服务端的偏航角。 */
	public float fakeYaw(ClientPlayerEntity player) {
		XdkSpinConfig config = XdkSpinConfig.get();
		float base = config.relativeToView ? player.getYaw() : 0.0F;
		return SpinMath.wrapDegrees(base + offsetDegrees);
	}

	/** 发往服务端的俯仰角。 */
	public float fakePitch(ClientPlayerEntity player) {
		XdkSpinConfig config = XdkSpinConfig.get();
		double pitch = switch (config.pitchMode) {
			case FIXED -> config.pitchAngle;
			case FOLLOW -> player.getPitch();
			case OFFSET -> player.getPitch() + config.pitchAngle;
		};
		return (float) XdkSpinConfig.clamp(pitch, XdkSpinConfig.PITCH_MIN, XdkSpinConfig.PITCH_MAX);
	}

	/** 关闭伪造，并把真实朝向立刻同步给服务端，让别人看到模型转回正常方向。 */
	public void disable(ClientPlayerEntity player) {
		spinning = false;
		fakeRotationSentThisTick = false;
		offsetDegrees = 0.0F;
		stepAccumulator = 0.0;
		if (player != null) {
			sendRealRotation(player);
		}
	}

	public void reset() {
		spinning = false;
		fakeRotationSentThisTick = false;
		offsetDegrees = 0.0F;
		stepAccumulator = 0.0;
		trackedPlayer = null;
	}

	/** 发出一个真实朝向的包（交互前纠正、关闭时归位都走这里）。 */
	public void sendRealRotation(ClientPlayerEntity player) {
		if (player == null) {
			return;
		}
		MinecraftClient client = MinecraftClient.getInstance();
		sendRotation(client, player, player.getYaw(), player.getPitch());
	}

	private void sendRotation(MinecraftClient client, ClientPlayerEntity player, float yaw, float pitch) {
		ClientPlayNetworkHandler handler = client.getNetworkHandler();
		if (handler == null) {
			return;
		}
		bypassRewrite = true;
		try {
			handler.sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(yaw, pitch, player.isOnGround(), player.horizontalCollision));
		} finally {
			bypassRewrite = false;
		}
	}
}
