package com.xdk.xdkspin;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class XdkSpinLog {
	public static final Logger LOGGER = LoggerFactory.getLogger("xdkspin");

	private XdkSpinLog() {
	}

	public static void info(String message) {
		LOGGER.info("[xdkspin] {}", message);
	}

	public static void warn(String message) {
		LOGGER.warn("[xdkspin] {}", message);
	}
}
