package com.xdk.xdkspin.mixin;

import com.xdk.xdkspin.SpinController;
import com.xdk.xdkspin.XdkSpinConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientCommonNetworkHandler;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerInteractBlockC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerInteractEntityC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerInteractItemC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

/**
 * 客户端所有发往服务端的包都会经过 ClientCommonNetworkHandler#sendPacket，这里是唯一的出口。
 * 在做旋转时：
 * <ul>
 *     <li>把移动包里的 yaw/pitch 换成伪造值（位置、onGround、horizontalCollision 原样保留）；</li>
 *     <li>在交互类包之前先补一个真实朝向的包，让服务端的射线/弹道/击退方向仍然用你的真实朝向。</li>
 * </ul>
 */
@Mixin(ClientCommonNetworkHandler.class)
public class ClientCommonNetworkHandlerMixin {
	@ModifyVariable(method = "sendPacket", at = @At("HEAD"), argsOnly = true)
	private Packet<?> xdkspin$spoofRotation(Packet<?> packet) {
		SpinController controller = SpinController.get();
		if (!controller.isSpinning() || controller.isBypassing()) {
			return packet;
		}

		MinecraftClient client = MinecraftClient.getInstance();
		ClientPlayerEntity player = client.player;
		if (player == null) {
			return packet;
		}

		if (packet instanceof PlayerMoveC2SPacket move) {
			if (!move.changesLook()) {
				return packet;
			}
			controller.markFakeRotationSent();
			float yaw = controller.fakeYaw(player);
			float pitch = controller.fakePitch(player);
			if (move.changesPosition()) {
				return new PlayerMoveC2SPacket.Full(
					move.getX(0.0), move.getY(0.0), move.getZ(0.0),
					yaw, pitch,
					move.isOnGround(), move.horizontalCollision());
			}
			return new PlayerMoveC2SPacket.LookAndOnGround(yaw, pitch, move.isOnGround(), move.horizontalCollision());
		}

		if (XdkSpinConfig.get().correctActions && isActionPacket(packet)) {
			controller.sendRealRotation(player);
		}
		return packet;
	}

	private static boolean isActionPacket(Packet<?> packet) {
		return packet instanceof PlayerActionC2SPacket
			|| packet instanceof PlayerInteractBlockC2SPacket
			|| packet instanceof PlayerInteractItemC2SPacket
			|| packet instanceof PlayerInteractEntityC2SPacket;
	}
}
