package com.xdk.xdkspin.mixin;

import com.xdk.xdkspin.SpinController;
import com.xdk.xdkspin.SpinMath;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.entity.PlayerLikeEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * 纯视觉：让自己在第三人称（F5）里看到的模型也跟着转，和别人的视角保持一致。
 * 只对本地玩家生效，其他玩家的渲染完全不受影响。
 */
@Mixin(PlayerEntityRenderer.class)
public class PlayerEntityRendererMixin {
	@Inject(method = "updateRenderState", at = @At("TAIL"))
	private void xdkspin$spinLocalModel(PlayerLikeEntity playerLike, PlayerEntityRenderState state, float tickProgress, CallbackInfo ci) {
		SpinController controller = SpinController.get();
		if (!controller.isSpinning()) {
			return;
		}
		ClientPlayerEntity self = MinecraftClient.getInstance().player;
		if (self == null || (Object) playerLike != self) {
			return;
		}
		state.bodyYaw = SpinMath.wrapDegrees(state.bodyYaw + controller.getOffsetDegrees());
		state.pitch = controller.fakePitch(self);
	}
}
