package com.xdk.xdkspin.gui;

/**
 * 面板布局计算（纯数学，不依赖 Minecraft，便于自检）。
 *
 * <p>约束：
 * <ul>
 *     <li>行距永远不小于控件高度，保证行与行不会重叠；</li>
 *     <li>在能放下的前提下自适应缩小行距，让"控件 + 底部提示"完整落在屏幕内；</li>
 *     <li>屏幕太矮时优先保证行距不小于控件高度（可能轻微超出屏幕），而不是压扁到重叠。</li>
 * </ul>
 */
public final class PanelLayout {
	public static final int ROW_HEIGHT = 20;
	public static final int MIN_ROW_STEP = ROW_HEIGHT;
	public static final int MAX_ROW_STEP = 23;
	/** 底部提示文字预留的高度（三段文字 + 两个空行，居中显示）。 */
	public static final int FOOTER_HEIGHT = 80;
	/** 控件区最小起始高度：要留出顶部标题和右上角"完成"按钮（y=6，高 20）的空间。 */
	public static final int TOP_MIN = 28;
	public static final int GAP = 10;
	public static final int MIN_COLUMN_WIDTH = 110;
	public static final int MAX_COLUMN_WIDTH = 200;
	public static final int SIDE_MARGIN = 10;
	public static final int DONE_WIDTH = 80;
	public static final int DONE_HEIGHT = 20;
	public static final int DONE_Y = 6;

	public final int screenWidth;
	public final int screenHeight;
	public final int rows;
	public final int rowStep;
	public final int columnWidth;
	public final int leftX;
	public final int rightX;
	public final int contentHeight;
	public final int top;
	public final int noticeY;
	public final int doneX;
	public final int doneY;

	private PanelLayout(int screenWidth, int screenHeight, int rows, int rowStep, int columnWidth,
						int leftX, int rightX, int contentHeight, int top, int noticeY, int doneX, int doneY) {
		this.screenWidth = screenWidth;
		this.screenHeight = screenHeight;
		this.rows = rows;
		this.rowStep = rowStep;
		this.columnWidth = columnWidth;
		this.leftX = leftX;
		this.rightX = rightX;
		this.contentHeight = contentHeight;
		this.top = top;
		this.noticeY = noticeY;
		this.doneX = doneX;
		this.doneY = doneY;
	}

	public static PanelLayout compute(int screenWidth, int screenHeight, int rows) {
		int rowStep = MAX_ROW_STEP;
		while (rowStep > MIN_ROW_STEP && TOP_MIN + rows * rowStep + FOOTER_HEIGHT > screenHeight) {
			rowStep--;
		}

		int columnWidth = Math.max(MIN_COLUMN_WIDTH, Math.min(MAX_COLUMN_WIDTH, (screenWidth - 2 * SIDE_MARGIN - GAP) / 2));
		int totalWidth = columnWidth * 2 + GAP;
		int leftX = (screenWidth - totalWidth) / 2;
		int rightX = leftX + columnWidth + GAP;
		int contentHeight = rows * rowStep;
		int top = Math.max(TOP_MIN, (screenHeight - contentHeight - FOOTER_HEIGHT) / 2);
		int noticeY = Math.min(top + contentHeight + 4, Math.max(TOP_MIN, screenHeight - FOOTER_HEIGHT + 4));
		int doneX = screenWidth - DONE_WIDTH - 6;

		return new PanelLayout(screenWidth, screenHeight, rows, rowStep, columnWidth, leftX, rightX,
			contentHeight, top, noticeY, doneX, DONE_Y);
	}

	/** 提示文字每行绘制的水平中心：屏幕正中（也是两列控件中间那条缝）。 */
	public static int noticeCenterX(int screenWidth) {
		return screenWidth / 2;
	}

	/** 提示文字的折行宽度（左右各留一点边距，避免顶到屏幕边缘）。 */
	public static int noticeWrapWidth(int screenWidth) {
		return screenWidth - 2 * SIDE_MARGIN;
	}

	/**
	 * 把颜色值补成不透明 ARGB。
	 * <p>绘制文字的颜色参数是 ARGB：只给 RGB（alpha=0）会画成完全透明，等于文字消失。
	 */
	public static int opaqueColor(Integer rgb) {
		return 0xFF000000 | (rgb != null ? rgb : 0xFFFFFF);
	}

	/** 两列控件的水平中心。 */
	public int columnsCenterX() {
		return leftX + (columnWidth * 2 + GAP) / 2;
	}

	/** 提示文字的中心是否与两列控件的中点重合（也就是屏幕正中）。 */
	public boolean noticeCenteredOnScreen() {
		return noticeCenterX(screenWidth) == columnsCenterX();
	}

	/** 控件与底部提示是否完整落在屏幕内。 */
	public boolean fitsVertically() {
		return top + contentHeight + FOOTER_HEIGHT <= screenHeight;
	}

	/** 底部提示是否会和最后一行控件重叠。 */
	public boolean noticeOverlapsContent() {
		return noticeY < top + contentHeight;
	}

	/** 两列是否横向放得下（含左右边距）。 */
	public boolean fitsHorizontally() {
		return leftX >= 0 && rightX + columnWidth <= screenWidth;
	}

	/** 完成按钮是否和标题区域重叠（按钮在右上角，纵向至少要在控件之上）。 */
	public boolean doneClearsContent() {
		return doneY + DONE_HEIGHT <= top;
	}
}
