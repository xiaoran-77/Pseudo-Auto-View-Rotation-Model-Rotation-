package com.xdk.xdkspin.gui;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.narration.NarrationMessageBuilder;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.text.MutableText;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.List;

/**
 * 底部提示控件：把每段文字按 {@code wrapWidth} 折行后，**每一行都画在控件自身的水平中心上**。
 *
 * <p>之所以不用 {@code MultilineTextWidget}：它内部会把控件宽度重算成"最宽那一行"的宽度，
 * 于是整块文字以控件的 x（左边距）为起点居中，视觉上会明显偏左。
 * 这里控件 x=0、宽度=整屏宽，所以控件中心恒等于屏幕正中（也就是两列控件中间那条缝）。
 */
public class NoticeWidget extends ClickableWidget {
	private static final int LINE_SPACING = 1;

	private final TextRenderer textRenderer;
	private final int wrapWidth;
	private final List<Paragraph> paragraphs;

	public NoticeWidget(TextRenderer textRenderer, int screenWidth, int y, int wrapWidth, List<Paragraph> paragraphs) {
		super(0, y, screenWidth, 0, Text.empty());
		this.textRenderer = textRenderer;
		this.wrapWidth = wrapWidth;
		this.paragraphs = paragraphs;
		this.setHeight(this.computeHeight());
	}

	/** 一段提示文字及其绘制颜色。 */
	public record Paragraph(Text text, int color) {
	}

	/** 生成一段带颜色的提示文字（颜色同时写进文本样式，并单独保留不透明 ARGB 作为兜底）。 */
	public static Paragraph paragraph(MutableText text, Formatting formatting) {
		return new Paragraph(text.formatted(formatting), PanelLayout.opaqueColor(formatting.getColorValue()));
	}

	private int computeHeight() {
		int lineHeight = this.textRenderer.fontHeight + LINE_SPACING;
		int lines = 0;
		for (int i = 0; i < this.paragraphs.size(); i++) {
			lines += this.textRenderer.wrapLines(this.paragraphs.get(i).text(), this.wrapWidth).size();
			if (i < this.paragraphs.size() - 1) {
				lines++; // 段间空一行
			}
		}
		return Math.max(lines, 1) * lineHeight;
	}

	@Override
	protected void renderWidget(DrawContext context, int mouseX, int mouseY, float deltaTicks) {
		int centerX = this.getX() + this.getWidth() / 2;
		int lineHeight = this.textRenderer.fontHeight + LINE_SPACING;
		int y = this.getY();
		for (int i = 0; i < this.paragraphs.size(); i++) {
			Paragraph paragraph = this.paragraphs.get(i);
			for (OrderedText line : this.textRenderer.wrapLines(paragraph.text(), this.wrapWidth)) {
				context.drawCenteredTextWithShadow(this.textRenderer, line, centerX, y, paragraph.color());
				y += lineHeight;
			}
			if (i < this.paragraphs.size() - 1) {
				y += lineHeight; // 空一行
			}
		}
	}

	@Override
	protected void appendClickableNarrations(NarrationMessageBuilder builder) {
		// 纯展示控件，不参与朗读
	}
}
