package com.xdk.xdkspin.gui;

import com.xdk.xdkspin.PitchMode;
import com.xdk.xdkspin.SpinController;
import com.xdk.xdkspin.SpinMath;
import com.xdk.xdkspin.SpinMode;
import com.xdk.xdkspin.XdkSpinConfig;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextWidget;
import net.minecraft.client.gui.widget.Widget;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.function.UnaryOperator;

/**
 * 设置面板：左列是旋转参数，右列是朝向与各种开关，全部改动即时生效。
 *
 * <p>旋转参数只显示当前模式真正生效的那几个，切换模式时立刻显隐并重排：
 * 每秒圈数模式只有"每秒旋转圈数"；单步角度模式只有"单次旋转角度"；
 * 角度加次数模式只有"每次旋转角度 + 每秒尝试次数"。
 * 所有控件只在 init() 里创建一次，切换模式不重建控件树，避免操作过程中修改控件列表。
 */
public class XdkSpinScreen extends Screen {
	private static final int ROW_HEIGHT = PanelLayout.ROW_HEIGHT;
	/** 右列的控件数量（固定）。 */
	private static final int RIGHT_ROWS = 8;

	private final Screen parent;
	private final XdkSpinConfig config = XdkSpinConfig.get();
	private final List<Runnable> refreshers = new ArrayList<>();

	// 布局参数（init 时算好，切换模式重排时复用）
	private int leftX;
	private int leftTop;
	private int rowStep;

	// 左列控件
	private TextWidget infoWidget;
	private DoubleSlider rpsSlider;
	private DoubleSlider stepSlider;
	private DoubleSlider customAngleSlider;
	private DoubleSlider customAttemptsSlider;
	/** 只在"每秒圈数/单次旋转角度"模式下显示的占位控件，用来占住第二行参数的位置。 */
	private ButtonWidget placeholderButton;
	// 左列固定行
	private ButtonWidget masterButton;
	private ButtonWidget modeButton;
	private ButtonWidget directionButton;
	private ButtonWidget relativeButton;

	// 右列控件（其中俯仰角度滑条在"跟随视角"模式下置灰）
	private DoubleSlider pitchSlider;

	public XdkSpinScreen(Screen parent) {
		super(Text.translatable("screen.xdkspin.title"));
		this.parent = parent;
	}

	@Override
	protected void init() {
		this.refreshers.clear();

		// 行数按"最满的模式"算，保证切换模式时整体布局不跳动
		int maxLeftRows = 1 /*总开关*/ + 1 /*模式*/ + 2 /*最多的参数*/ + 1 /*方向*/ + 1 /*相对视角*/ + 1 /*等效值*/;
		int rows = Math.max(maxLeftRows, RIGHT_ROWS);

		PanelLayout layout = PanelLayout.compute(this.width, this.height, rows);
		int rowStep = layout.rowStep;
		int columnWidth = layout.columnWidth;
		int left = layout.leftX;
		int right = layout.rightX;
		int top = layout.top;

		this.leftX = left;
		this.leftTop = top;
		this.rowStep = rowStep;

		// ---------- 左列：总开关、旋转模式、模式相关参数、方向、相对视角 ----------
		this.masterButton = this.toggle(left, top, columnWidth, "option.xdkspin.enabled", () -> this.config.enabled, value -> {
			this.config.enabled = value;
			if (!value && this.client != null) {
				SpinController.get().disable(this.client.player);
			}
		});
		this.addDrawableChild(this.masterButton);

		this.modeButton = this.cycle(left, top, columnWidth, "option.xdkspin.spin_mode",
			() -> this.config.spinMode, SpinMode::next,
			value -> {
				this.config.spinMode = value;
				// 只显隐并重排，不动控件列表
				this.layoutLeftColumn();
			},
			value -> Text.translatable(switch (value) {
				case RPS -> "value.xdkspin.mode.rps";
				case STEP -> "value.xdkspin.mode.step";
				case CUSTOM -> "value.xdkspin.mode.custom";
			}));
		this.addDrawableChild(this.modeButton);

		this.rpsSlider = new DoubleSlider(left, top, columnWidth, ROW_HEIGHT, "option.xdkspin.rps",
			XdkSpinConfig.RPS_MIN, XdkSpinConfig.RPS_MAX, 0.05, this.config.rotationsPerSecond, "%.2f",
			value -> this.config.rotationsPerSecond = value, this::refreshInfo);
		this.addDrawableChild(this.rpsSlider);

		this.stepSlider = new DoubleSlider(left, top, columnWidth, ROW_HEIGHT, "option.xdkspin.step",
			XdkSpinConfig.STEP_MIN, XdkSpinConfig.STEP_MAX, 0.1, this.config.stepAngle, "%.1f",
			value -> this.config.stepAngle = value, this::refreshInfo);
		this.addDrawableChild(this.stepSlider);

		this.customAngleSlider = new DoubleSlider(left, top, columnWidth, ROW_HEIGHT, "option.xdkspin.custom_angle",
			XdkSpinConfig.STEP_MIN, XdkSpinConfig.STEP_MAX, 0.1, this.config.customStepAngle, "%.1f",
			value -> this.config.customStepAngle = value, this::refreshInfo);
		this.addDrawableChild(this.customAngleSlider);

		this.customAttemptsSlider = new DoubleSlider(left, top, columnWidth, ROW_HEIGHT, "option.xdkspin.custom_attempts",
			XdkSpinConfig.ATTEMPTS_MIN, XdkSpinConfig.ATTEMPTS_MAX, 0.05, this.config.customAttemptsPerSecond, "%.2f",
			value -> this.config.customAttemptsPerSecond = value, this::refreshInfo);
		this.addDrawableChild(this.customAttemptsSlider);

		// 占位控件：只在参数只有一行的模式（每秒圈数 / 单次旋转角度）下显示，
		// 让下面的"旋转方向、相对视角旋转"永远停在同一个位置，切换模式时不跳动。
		this.placeholderButton = ButtonWidget.builder(
			Text.translatable("option.xdkspin.placeholder").formatted(Formatting.LIGHT_PURPLE),
			button -> {
				// 纯占位，点了也不做任何事
			}).dimensions(left, top, columnWidth, ROW_HEIGHT).build();
		this.addDrawableChild(this.placeholderButton);

		this.directionButton = this.cycle(left, top, columnWidth, "option.xdkspin.direction",
			() -> this.config.clockwise, value -> !value, value -> this.config.clockwise = value,
			value -> Text.translatable(value ? "value.xdkspin.clockwise" : "value.xdkspin.counterclockwise"));
		this.addDrawableChild(this.directionButton);

		this.relativeButton = this.toggle(left, top, columnWidth, "option.xdkspin.relative",
			() -> this.config.relativeToView, value -> this.config.relativeToView = value);
		this.addDrawableChild(this.relativeButton);

		this.infoWidget = new TextWidget(left, top, columnWidth, ROW_HEIGHT, Text.empty(), this.textRenderer);
		this.addDrawableChild(this.infoWidget);

		// ---------- 右列：头部朝向与自动停止 ----------
		int y = top;
		this.addDrawableChild(this.cycle(right, y, columnWidth, "option.xdkspin.pitch_mode",
			() -> this.config.pitchMode, PitchMode::next, value -> this.config.pitchMode = value,
			value -> Text.translatable(switch (value) {
				case FIXED -> "value.xdkspin.pitch.fixed";
				case FOLLOW -> "value.xdkspin.pitch.follow";
				case OFFSET -> "value.xdkspin.pitch.offset";
			})));
		y += rowStep;

		this.pitchSlider = new DoubleSlider(right, y, columnWidth, ROW_HEIGHT, "option.xdkspin.pitch",
			XdkSpinConfig.PITCH_MIN, XdkSpinConfig.PITCH_MAX, 1.0, this.config.pitchAngle, "%.0f",
			value -> this.config.pitchAngle = value, null);
		this.addDrawableChild(this.pitchSlider);
		y += rowStep;

		this.addDrawableChild(this.toggle(right, y, columnWidth, "option.xdkspin.stop_swimming",
			() -> this.config.stopWhileSwimming, value -> this.config.stopWhileSwimming = value));
		y += rowStep;
		this.addDrawableChild(this.toggle(right, y, columnWidth, "option.xdkspin.stop_gliding",
			() -> this.config.stopWhileGliding, value -> this.config.stopWhileGliding = value));
		y += rowStep;
		this.addDrawableChild(this.toggle(right, y, columnWidth, "option.xdkspin.stop_riding",
			() -> this.config.stopWhileRiding, value -> this.config.stopWhileRiding = value));
		y += rowStep;
		this.addDrawableChild(this.toggle(right, y, columnWidth, "option.xdkspin.stop_dead",
			() -> this.config.stopWhileDead, value -> this.config.stopWhileDead = value));
		y += rowStep;
		this.addDrawableChild(this.toggle(right, y, columnWidth, "option.xdkspin.correct_actions",
			() -> this.config.correctActions, value -> this.config.correctActions = value));
		y += rowStep;
		this.addDrawableChild(this.toggle(right, y, columnWidth, "option.xdkspin.chat_feedback",
			() -> this.config.chatFeedback, value -> this.config.chatFeedback = value));

		// ---------- 底部提示：三段文字、段间空一行，每行都画在屏幕水平正中 ----------
		// 刻意不用 MultilineTextWidget：它会把控件宽度重算成"最宽那一行"的宽度，
		// 整块文字以左边距为起点而偏左；NoticeWidget 的 x=0、宽=整屏，中心恒为屏幕正中。
		this.addDrawableChild(new NoticeWidget(this.textRenderer, this.width, layout.noticeY,
			PanelLayout.noticeWrapWidth(this.width), List.of(
				NoticeWidget.paragraph(Text.translatable("screen.xdkspin.notice"), Formatting.YELLOW),
				NoticeWidget.paragraph(Text.translatable("screen.xdkspin.notice2"), Formatting.GRAY),
				NoticeWidget.paragraph(Text.translatable("screen.xdkspin.notice3"), Formatting.RED))));

		// 完成按钮放右上角，避免和底部提示抢空间
		this.addDrawableChild(ButtonWidget.builder(Text.translatable("screen.xdkspin.done"), button -> this.close())
			.dimensions(layout.doneX, layout.doneY, PanelLayout.DONE_WIDTH, PanelLayout.DONE_HEIGHT)
			.build());

		this.layoutLeftColumn();
	}

	/**
	 * 按当前模式显隐并重排左列：只留当前模式生效的参数项，后面的控件自动上移。
	 */
	private void layoutLeftColumn() {
		SpinMode mode = this.config.spinMode;

		this.setParamVisible(this.rpsSlider, mode == SpinMode.RPS);
		this.setParamVisible(this.stepSlider, mode == SpinMode.STEP);
		this.setParamVisible(this.customAngleSlider, mode == SpinMode.CUSTOM);
		this.setParamVisible(this.customAttemptsSlider, mode == SpinMode.CUSTOM);

		int y = this.leftTop;
		this.masterButton.setPosition(this.leftX, y);
		y += this.rowStep;
		this.modeButton.setPosition(this.leftX, y);
		y += this.rowStep;

		// 第二行参数位：自定义模式是自己的第二个参数，其余模式用占位控件顶住位置
		this.placeholderButton.visible = mode != SpinMode.CUSTOM;
		this.customAttemptsSlider.visible = mode == SpinMode.CUSTOM;
		this.customAttemptsSlider.active = mode == SpinMode.CUSTOM;

		switch (mode) {
			case RPS -> {
				this.rpsSlider.setPosition(this.leftX, y);
				y += this.rowStep;
				this.placeholderButton.setPosition(this.leftX, y);
				y += this.rowStep;
			}
			case STEP -> {
				this.stepSlider.setPosition(this.leftX, y);
				y += this.rowStep;
				this.placeholderButton.setPosition(this.leftX, y);
				y += this.rowStep;
			}
			case CUSTOM -> {
				this.customAngleSlider.setPosition(this.leftX, y);
				y += this.rowStep;
				this.customAttemptsSlider.setPosition(this.leftX, y);
				y += this.rowStep;
			}
		}

		this.directionButton.setPosition(this.leftX, y);
		y += this.rowStep;
		this.relativeButton.setPosition(this.leftX, y);
		y += this.rowStep;
		this.infoWidget.setPosition(this.leftX, y + 3);

		this.refreshInfo();
	}

	private void setParamVisible(DoubleSlider slider, boolean visible) {
		slider.visible = visible;
		slider.active = visible;
	}

	@Override
	public void tick() {
		super.tick();
		for (Runnable refresh : this.refreshers) {
			refresh.run();
		}
		// 俯仰模式为"跟随视角"时，俯仰角度滑条不生效，置灰
		if (this.pitchSlider != null) {
			this.pitchSlider.active = this.config.pitchMode != PitchMode.FOLLOW;
		}
		this.refreshInfo();
	}

	@Override
	public void close() {
		XdkSpinConfig.save();
		if (this.client != null) {
			this.client.setScreen(this.parent);
		}
	}

	private void refreshInfo() {
		if (this.infoWidget == null) {
			return;
		}
		double perTick = this.config.degreesPerTick();
		double rps = SpinMath.rotationsPerSecond(perTick);
		String rpsText = String.format(Locale.ROOT, "%.2f", rps);
		String perTickText = String.format(Locale.ROOT, "%.1f", perTick);
		// 三种模式都只显示"每秒圈数 + 每 tick 度数"，不显示计算公式
		Text text = Text.translatable("screen.xdkspin.info", rpsText, perTickText);
		if (perTick > 90.0) {
			text = text.copy().append(Text.translatable("screen.xdkspin.info.warn"));
		}
		this.infoWidget.setMessage(text);
	}

	private ButtonWidget toggle(int x, int y, int width, String labelKey, Supplier<Boolean> getter, Consumer<Boolean> setter) {
		ButtonWidget button = ButtonWidget.builder(Text.empty(), b -> {
			boolean value = !getter.get();
			setter.accept(value);
			b.setMessage(onOffLabel(labelKey, value));
		}).dimensions(x, y, width, ROW_HEIGHT).build();
		Runnable refresh = () -> button.setMessage(onOffLabel(labelKey, getter.get()));
		refresh.run();
		this.refreshers.add(refresh);
		return button;
	}

	private <T> ButtonWidget cycle(int x, int y, int width, String labelKey, Supplier<T> getter,
								   UnaryOperator<T> next, Consumer<T> setter, Function<T, Text> valueToText) {
		ButtonWidget button = ButtonWidget.builder(Text.empty(), b -> {
			T value = next.apply(getter.get());
			setter.accept(value);
			b.setMessage(cycleLabel(labelKey, valueToText.apply(value)));
		}).dimensions(x, y, width, ROW_HEIGHT).build();
		Runnable refresh = () -> button.setMessage(cycleLabel(labelKey, valueToText.apply(getter.get())));
		refresh.run();
		this.refreshers.add(refresh);
		return button;
	}

	private static Text onOffLabel(String labelKey, boolean value) {
		return cycleLabel(labelKey, Text.translatable(value ? "value.xdkspin.on" : "value.xdkspin.off"));
	}

	private static Text cycleLabel(String labelKey, Text value) {
		return Text.translatable(labelKey).append(Text.literal(": ")).append(value);
	}
}
