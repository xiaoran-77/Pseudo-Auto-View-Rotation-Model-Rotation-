package com.xdk.xdkspin.gui;

import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;

import java.util.Locale;
import java.util.function.Consumer;

/**
 * 一个显示“名称: 当前值”的浮点滑条。
 */
public class DoubleSlider extends SliderWidget {
	private final String labelKey;
	private final double min;
	private final double max;
	private final double step;
	private final String format;
	private final Consumer<Double> onChange;
	private final Runnable onChanged;

	public DoubleSlider(int x, int y, int width, int height, String labelKey, double min, double max, double step,
						double value, String format, Consumer<Double> onChange, Runnable onChanged) {
		super(x, y, width, height, Text.empty(), toProgress(value, min, max));
		this.labelKey = labelKey;
		this.min = min;
		this.max = max;
		this.step = step;
		this.format = format;
		this.onChange = onChange;
		this.onChanged = onChanged;
		this.updateMessage();
	}

	private static double toProgress(double value, double min, double max) {
		if (max <= min) {
			return 0.0;
		}
		return Math.max(0.0, Math.min(1.0, (value - min) / (max - min)));
	}

	/** 吸附到步进后的实际数值。 */
	public double getDoubleValue() {
		double raw = this.min + (this.max - this.min) * this.value;
		double snapped = Math.round(raw / this.step) * this.step;
		return Math.max(this.min, Math.min(this.max, snapped));
	}

	@Override
	protected void updateMessage() {
		if (this.labelKey == null) {
			this.setMessage(Text.empty());
			return;
		}
		String shown = String.format(Locale.ROOT, this.format, this.getDoubleValue());
		this.setMessage(Text.translatable(this.labelKey).append(Text.literal(": " + shown)));
	}

	@Override
	protected void applyValue() {
		this.updateMessage();
		this.onChange.accept(this.getDoubleValue());
		if (this.onChanged != null) {
			this.onChanged.run();
		}
	}
}
