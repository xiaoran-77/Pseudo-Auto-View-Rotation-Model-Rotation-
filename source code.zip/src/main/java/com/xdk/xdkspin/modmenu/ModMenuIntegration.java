package com.xdk.xdkspin.modmenu;

import com.terraformersmc.modmenu.api.ConfigScreenFactory;
import com.terraformersmc.modmenu.api.ModMenuApi;
import com.xdk.xdkspin.gui.XdkSpinScreen;

/**
 * 仅在装了 Mod Menu 时加载，用于在模组列表里加一个设置按钮。
 */
public class ModMenuIntegration implements ModMenuApi {
	@Override
	public ConfigScreenFactory<?> getModConfigScreenFactory() {
		return parent -> new XdkSpinScreen(parent);
	}
}
