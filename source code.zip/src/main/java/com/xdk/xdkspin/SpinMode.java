package com.xdk.xdkspin;

/**
 * 旋转速度的表示方式。
 */
public enum SpinMode {
	/** 直接指定每秒转多少圈，内部换算成每 tick 的角度。 */
	RPS,
	/** 直接指定每 tick 转多少度（20 tick = 1 秒）。 */
	STEP,
	/** 自定义：每次转多少度 × 每秒尝试转多少次，按频率跳跃而不是每 tick 均匀铺开。 */
	CUSTOM;

	public SpinMode next() {
		SpinMode[] values = values();
		return values[(ordinal() + 1) % values.length];
	}
}
