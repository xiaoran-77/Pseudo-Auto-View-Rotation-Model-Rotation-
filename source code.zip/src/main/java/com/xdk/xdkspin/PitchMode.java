package com.xdk.xdkspin;

/**
 * 头部俯仰角（垂直朝向）的来源。
 */
public enum PitchMode {
	/** 固定角度，不随自己的视角变化。 */
	FIXED,
	/** 完全跟随自己的真实俯仰角。 */
	FOLLOW,
	/** 在自己真实俯仰角的基础上再加一个偏移量。 */
	OFFSET;

	public PitchMode next() {
		PitchMode[] values = values();
		return values[(this.ordinal() + 1) % values.length];
	}
}
