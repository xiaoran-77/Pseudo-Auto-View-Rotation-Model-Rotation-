package com.xdk.xdkspin;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * 所有可调项。面板里每一项都可以改，改完立刻写盘。
 */
public final class XdkSpinConfig {
	public static final double RPS_MIN = 0.05;
	public static final double RPS_MAX = 10.0;
	/** 单次旋转角度 / 自定义模式的每次旋转角度，下限 0.1 度。 */
	public static final double STEP_MIN = 0.1;
	public static final double STEP_MAX = 180.0;
	/** 自定义模式的每秒尝试次数。上限 20 = 客户端每秒的 tick 数，再多也只是同一 tick 内多次跳。 */
	public static final double ATTEMPTS_MIN = 0.05;
	public static final double ATTEMPTS_MAX = 20.0;
	public static final double PITCH_MIN = -90.0;
	public static final double PITCH_MAX = 90.0;

	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
	private static final String FILE_NAME = "xdkspin.json";
	private static XdkSpinConfig instance = new XdkSpinConfig();

	/** 总开关。 */
	public boolean enabled = false;

	/** 旋转参数。 */
	public SpinMode spinMode = SpinMode.RPS;
	public double rotationsPerSecond = 1.0;
	public double stepAngle = 18.0;
	/** 自定义模式：每次旋转多少度。 */
	public double customStepAngle = 15.0;
	/** 自定义模式：每秒尝试旋转多少次。 */
	public double customAttemptsPerSecond = 5.0;
	public boolean clockwise = true;
	/** true = 相对自己的视角旋转；false = 绝对方向自转。 */
	public boolean relativeToView = false;

	/** 头的垂直朝向。 */
	public PitchMode pitchMode = PitchMode.FIXED;
	public double pitchAngle = 0.0;

	/** 自动停止条件。 */
	public boolean stopWhileSwimming = true;
	public boolean stopWhileGliding = true;
	public boolean stopWhileRiding = true;
	public boolean stopWhileDead = true;

	/** 交互（挖掘/放置/使用/攻击）之前先补发一个真实朝向包，保证操作不受影响。 */
	public boolean correctActions = true;
	/** 开关时在聊天栏打印本地提示。 */
	public boolean chatFeedback = true;

	private XdkSpinConfig() {
	}

	public static XdkSpinConfig get() {
		return instance;
	}

	public static Path file() {
		return FabricLoader.getInstance().getConfigDir().resolve(FILE_NAME);
	}

	public static void load() {
		Path path = file();
		XdkSpinConfig loaded = new XdkSpinConfig();
		if (Files.exists(path)) {
			try {
				String json = Files.readString(path, StandardCharsets.UTF_8);
				XdkSpinConfig parsed = GSON.fromJson(json, XdkSpinConfig.class);
				if (parsed != null) {
					// 老配置文件缺少新字段时，Gson 会保留字段默认值，因此旧配置依然可用
					loaded = parsed;
				}
			} catch (Exception e) {
				XdkSpinLog.warn("配置文件读取失败，已使用默认值: " + e);
			}
		}
		loaded.validate();
		instance = loaded;
		if (!Files.exists(path)) {
			save();
		}
	}

	public static void save() {
		Path path = file();
		try {
			Files.createDirectories(path.getParent());
			Files.writeString(path, GSON.toJson(instance), StandardCharsets.UTF_8);
		} catch (IOException e) {
			XdkSpinLog.warn("配置文件写入失败: " + e);
		}
	}

	/** 修正非法值，避免手改配置把游戏搞坏。 */
	public void validate() {
		if (spinMode == null) {
			spinMode = SpinMode.RPS;
		}
		if (pitchMode == null) {
			pitchMode = PitchMode.FIXED;
		}
		rotationsPerSecond = clamp(rotationsPerSecond, RPS_MIN, RPS_MAX);
		stepAngle = clamp(stepAngle, STEP_MIN, STEP_MAX);
		customStepAngle = clamp(customStepAngle, STEP_MIN, STEP_MAX);
		customAttemptsPerSecond = clamp(customAttemptsPerSecond, ATTEMPTS_MIN, ATTEMPTS_MAX);
		pitchAngle = clamp(pitchAngle, PITCH_MIN, PITCH_MAX);
	}

	public static double clamp(double value, double min, double max) {
		if (Double.isNaN(value)) {
			return min;
		}
		return Math.max(min, Math.min(max, value));
	}

	/** 当前配置下的平均每 tick 角度。 */
	public double degreesPerTick() {
		return SpinMath.degreesPerTick(spinMode, rotationsPerSecond, stepAngle, customAttemptsPerSecond, customStepAngle);
	}
}
