package com.xdk.xdkspin;

/**
 * 纯计算的旋转数学，刻意不依赖任何 Minecraft 类，方便单独做自检。
 */
public final class SpinMath {
	public static final double TICKS_PER_SECOND = 20.0;
	public static final double FULL_TURN = 360.0;

	private SpinMath() {
	}

	/**
	 * 平均每 tick 旋转的角度。
	 * <p>自定义模式是"每次 X 度 × 每秒 N 次"，平均到每 tick 就是 N × X ÷ 20，
	 * 实际跳跃时机由 {@link com.xdk.xdkspin.SpinController} 的累加器控制。
	 */
	public static double degreesPerTick(SpinMode mode, double rotationsPerSecond, double stepAngle,
										double attemptsPerSecond, double customStepAngle) {
		return switch (mode) {
			case RPS -> rotationsPerSecond * FULL_TURN / TICKS_PER_SECOND;
			case STEP -> stepAngle;
			case CUSTOM -> attemptsPerSecond * customStepAngle / TICKS_PER_SECOND;
		};
	}

	/** 由每 tick 角度反推每秒圈数，用于面板显示等效值。 */
	public static double rotationsPerSecond(double degreesPerTick) {
		return degreesPerTick * TICKS_PER_SECOND / FULL_TURN;
	}

	/** 把任意角度折算到 [-180, 180)，与 Minecraft 的 wrapDegrees 语义一致。 */
	public static float wrapDegrees(double degrees) {
		double wrapped = degrees % FULL_TURN;
		if (wrapped >= 180.0) {
			wrapped -= FULL_TURN;
		}
		if (wrapped < -180.0) {
			wrapped += FULL_TURN;
		}
		return (float) wrapped;
	}

	/** 累加一步旋转，并保持在 [-180, 180) 区间内。 */
	public static float advance(float offsetDegrees, double degreesPerStep, boolean clockwise) {
		double delta = clockwise ? degreesPerStep : -degreesPerStep;
		return wrapDegrees(offsetDegrees + delta);
	}
}
