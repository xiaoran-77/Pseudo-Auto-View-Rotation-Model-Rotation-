# XDK Spin（模型自动旋转）

Fabric **1.21.11** 纯客户端模组：让**服务端和其他玩家**看到你的角色模型一直在转，而你自己的视角、移动、挖掘、放置、攻击、射箭等操作完全不受影响。

- 打开设置面板：**F8**（可在原版按键设置里改）
- 快捷开关：**F7**
- 开关提示会打印在聊天栏（仅自己可见）：`[自动旋转]:开启`（黄 + 绿）/ `[自动旋转]:关闭`（黄 + 红）

## 原理（为什么是"别人看得到、自己没感觉"）

Minecraft 里玩家的朝向是客户端说了算的：客户端每 tick 把 yaw/pitch 放进 `PlayerMoveC2SPacket` 发给服务端，服务端不校验，直接转发给附近玩家，别人客户端就用这个值渲染你的模型。

本模组只在**网络出口**把这两个数值换成旋转值，本地摄像机用的字段完全不碰，所以：

- 你的第一人称视角、鼠标输入、移动、跳跃、攻击判定都没有任何变化；
- 其他玩家（以及服务端）看到的模型朝向会持续旋转；
- 你自己在 F5 第三人称里，会看到自己的模型也在转（纯视觉，由渲染层实现）。

为了不让"服务端以为你在看别的方向"影响操作，任何交互包（挖掘 `PlayerActionC2SPacket`、放置 `PlayerInteractBlockC2SPacket`、使用/射箭 `PlayerInteractItemC2SPacket`、攻击 `PlayerInteractEntityC2SPacket`）在发出之前，都会先补发一个带着**真实朝向**的包，服务端按顺序处理，所以射线检测、弹道方向、击退方向仍然用的是你真正的朝向。

## 设置面板里的所有项目

| 项目 | 说明 |
| --- | --- |
| 总开关 | 等效 F7 |
| 旋转模式 | 「每秒圈数」/「单次旋转角度」/「角度加次数」三选一；**面板只显示当前模式生效的参数**，参数只有一行的模式会用占位控件顶住第二行，保证「旋转方向」「相对视角旋转」的位置永远不动 |
| 每秒旋转圈数 | 0.05 ~ 10.0 圈/秒（1 圈/秒 = 18°/tick） |
| 单次旋转角度 | **0.1** ~ 180.0 度/tick（单步角度模式） |
| 每次旋转角度 | **0.1** ~ 180.0 度（角度加次数模式，每次跳跃转多少度） |
| 每秒尝试次数 | 0.05 ~ 20.0 次/秒（角度加次数模式；20 = 客户端每秒 tick 数） |
| 旋转方向 | 顺时针 / 逆时针 |
| 相对视角旋转 | 关 = 绝对方向自转；开 = 相对你的视角转 |
| 头部俯仰模式 | 固定角度 / 跟随视角 / 视角加偏移 |
| 头部俯仰角度 | -90 ~ 90 度（跟随视角模式下此项无效） |
| 游泳时自动停止 | 默认开，检测 `isSwimming()` |
| 鞘翅飞行时自动停止 | 默认开，1.21.11 里是 `isGliding()` |
| 骑乘时自动停止 | 默认开（骑乘时客户端根本不发玩家朝向包，转不动） |
| 死亡后自动停止 | 默认开 |
| 交互前补发真实朝向 | 默认开。**关掉它可能导致挖掘/放置/射箭方向错乱**，除非你明确知道后果 |
| 聊天栏开关提示 | 默认开 |

面板改完即生效（实时预览），关闭面板时写入配置文件 `config/xdkspin.json`。

## 安装

1. 环境要求：Fabric Loader **0.19.2+**、Fabric API **0.141.0+**（对应 MC 1.21.11）。
2. 把 `build/libs/xdkspin-1.0.0+1.21.11.jar` 复制到实例的 `mods` 文件夹。
3. 启动游戏，进游戏后按 **F8** 调设置，**F7** 开关。

Mod Menu 是可选集成（本模组不需要它，不装也能用；装了才会在模组列表里多一个设置按钮）。

## 风险提示（务必看）

- 本模组会**伪造发往服务端的朝向**。服务端确实能看到你在转，所以带旋转检测的反作弊（Vulcan、Matrix、部分 Grim 配置等）有可能标记、踢出甚至封禁；原版服务和 Paper 默认不校验旋转速度。
- 服务端一切基于朝向的逻辑都会拿到旋转值（怪物索敌方向、被击退方向、部分插件的"看向"判定）。模组已经用"交互前补发真实朝向"覆盖了挖掘/放置/使用/攻击，但极端情况下（同 tick 多个动作、高延迟）仍可能有微小竞态。
- 骑乘载具、鞘翅飞行、游泳等状态下建议保持默认的自动停止。

## 从源码构建

需要 **JDK 21**（`gradle.properties` 里的 `org.gradle.java.home` 已指向 `C:/Users/taixi/jdk-21`）。
Gradle 用仓库自带的 wrapper（9.5.1），插件是 Fabric Loom **1.17.21**（1.18.x 需要 JDK 25，刻意不用）：

```
gradlew.bat build      # Windows CMD / PowerShell
./gradlew build        # Git Bash
```

产物在 `build/libs/xdkspin-1.0.0+1.21.11.jar`。

数学部分有独立自检（不依赖 Minecraft）：

```
javac -encoding UTF-8 -d build/selfcheck tools/selfcheck/SelfCheck.java src/main/java/com/xdk/xdkspin/SpinMath.java src/main/java/com/xdk/xdkspin/SpinMode.java src/main/java/com/xdk/xdkspin/PitchMode.java
java -cp build/selfcheck SelfCheck
```

## 版本核对记录（全部来自官方来源，非记忆）

| 项目 | 取值 | 来源 |
| --- | --- | --- |
| Minecraft | 1.21.11（2025-12-09 发布，`javaVersion.majorVersion = 21`） | piston-meta `version_manifest_v2.json` → `1.21.11.json` |
| Yarn | 1.21.11+build.6 | `meta.fabricmc.net/v2/versions/yarn/1.21.11` |
| Fabric Loader | 0.19.5 | `meta.fabricmc.net/v2/versions/loader/1.21.11` |
| Fabric API | 0.141.6+1.21.11 | Modrinth API |
| Fabric Loom | 1.17.21（1.18.2 的 class 文件版本是 69=Java25，会强制要求 JDK 25） | `maven.fabricmc.net/.../fabric-loom/maven-metadata.xml` + 逐版本读 class 头 |
| Gradle | 9.5.1 | 官方模板 `FabricMC/fabric-example-mod@1.21.11` 的 wrapper |
| 编译目标 | `release = 21`（产物 class 版本实测 65） | 同上模板 + 产物校验 |
| Mixin 兼容级别 | `JAVA_21` | 同上模板的 `modid.mixins.json` |

## 更新记录

- **1.0.0**（2026-09-26）
  - 按键改为**独立分类**：在「按键控制」里单开一页 **「自动旋转器awa」**（`KeyBinding.Category.create(Identifier.of("xdkspin", "rotation"))`，标题取自语言文件 `key.category.xdkspin.rotation`；同一 id 只能注册一次，重复会抛异常）。
  - 模组列表信息更新：作者 `xiaoran_77`、许可证 `LGPL-3.0-only`（即 LGPLv3）、描述 `xiaoran_77无聊弄的mod-只有自动旋转功能-awa`。
  - 新增第三种旋转模式「角度加次数」：自定义每次跳跃的角度 × 每秒尝试次数（累加器实现，非整除频率也不漂移，例如 3 次/秒 = 每 6.67 tick 跳一次）。
  - 单次旋转角度下限从 0.5 放宽到 **0.1** 度（新模式的角度下限同为 0.1）。
  - 面板改为**按模式动态显示参数**：每秒圈数模式只有"每秒旋转圈数"，单次旋转角度模式只有"单次旋转角度"，角度加次数模式只有"每次旋转角度 + 每秒尝试次数"；参数只有一行的模式下，第二行参数位用一个粉色占位控件「【我就是占位置的QAQ】」顶住，因此「旋转方向」「相对视角旋转」在切换模式时**位置完全不动**。俯仰模式为"跟随视角"时，俯仰角度滑条置灰（不生效）。
  - 角度加次数模式的等效值只显示「每秒圈数 + 每 tick 度数」，不再显示"次数 × 角度"的计算公式。
  - 面板提示改为**每行都画在屏幕水平正中**（也就是两列控件中间那条缝），三段之间各空一行：第一段黄色、第二段淡灰色（服务器地址）、第三段红色（小云朵 YSM 提示）。实现上不用原版 `MultilineTextWidget`（它会把控件宽度重算成"最宽那一行"的宽度，导致整块文字以左边距为起点而偏左），改为自定义控件 `NoticeWidget` 逐行居中绘制。
  - 面板布局自适应行距，「完成」按钮移到右上角，保证 GUI 缩放 4 的小窗口也能完整显示。
  - 面板提示文案替换为指定内容（第一段黄色、空一行、第二段默认颜色）。
  - 数学自检扩充到 28 项（含累加器频率与平均换算一致性验证）。

## 代码结构

```
src/main/java/com/xdk/xdkspin/
├─ XdkSpinClient.java          客户端入口：注册 F7/F8 按键、tick 事件、聊天栏提示
├─ SpinController.java         旋转状态机：推进角度、自动停止条件、补发真实朝向
├─ SpinMath.java               纯数学：圈/秒 ↔ 度/tick、角度折算（可单独自检）
├─ XdkSpinConfig.java          config/xdkspin.json 读写与校验
├─ SpinMode.java / PitchMode.java
├─ gui/XdkSpinScreen.java      设置面板（原版控件，无额外依赖）
├─ gui/DoubleSlider.java       显示"名称: 当前值"的滑条
├─ modmenu/ModMenuIntegration.java  可选：Mod Menu 设置按钮
└─ mixin/
   ├─ ClientCommonNetworkHandlerMixin.java  改写移动包朝向 + 交互前补发真实朝向
   └─ PlayerEntityRendererMixin.java        本地第三人称模型同步旋转
```
